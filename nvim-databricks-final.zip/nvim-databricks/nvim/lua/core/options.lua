-- ============================================================
--  core/options.lua — NvimPP settings (Notepad++ feel)
-- ============================================================

local opt = vim.opt

-- UI
opt.number         = true          -- line numbers (like N++ margin)
opt.relativenumber = false
opt.cursorline     = true          -- highlight current line
opt.signcolumn     = "yes"
opt.colorcolumn    = ""
opt.ruler          = true
opt.showcmd        = true
opt.showmode       = false         -- lualine handles this
opt.termguicolors  = true
opt.pumheight      = 10
opt.laststatus     = 3             -- global statusline
opt.showtabline    = 2             -- always show tabs (like N++ tabs)

-- Editor
opt.tabstop        = 4
opt.shiftwidth     = 4
opt.expandtab      = true
opt.smartindent    = true
opt.wrap           = false
opt.scrolloff      = 8
opt.sidescrolloff  = 8
opt.splitbelow     = true
opt.splitright     = true

-- Search
opt.hlsearch       = true
opt.incsearch      = true
opt.ignorecase     = true
opt.smartcase      = true

-- Files
opt.backup         = false
opt.swapfile       = false
opt.undofile       = true
opt.undodir        = vim.fn.stdpath("data") .. "/undo"
opt.updatetime     = 250
opt.timeoutlen     = 400

-- Clipboard
opt.clipboard      = "unnamedplus"

-- Mouse
opt.mouse          = "a"

-- Fold (like N++ collapsing)
opt.foldmethod     = "indent"
opt.foldlevel      = 99

-- Filetype associations for Databricks notebooks
vim.filetype.add({
  extension = {
    dbc   = "python",  -- Databricks archive
    ipynb = "python",
  },
  pattern = {
    [".*%.py%.databricks"] = "python",
  },
})
