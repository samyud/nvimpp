-- ============================================================
--  core/keymaps.lua — Notepad++-inspired keybindings
-- ============================================================

local map = vim.keymap.set
local opts = { silent = true, noremap = true }

vim.g.mapleader = " "
vim.g.maplocalleader = "\\"

-- ── File / Editor (Notepad++ muscle memory) ─────────────────
map("n", "<C-s>",      "<cmd>w<CR>",                  { desc = "Save" })
map("n", "<C-S-s>",    "<cmd>wa<CR>",                 { desc = "Save all" })
map("n", "<C-w>",      "<cmd>bd<CR>",                 { desc = "Close tab/buffer" })
map("n", "<C-n>",      "<cmd>enew<CR>",               { desc = "New file" })
map("n", "<C-z>",      "u",                           { desc = "Undo" })
map("n", "<C-y>",      "<C-r>",                       { desc = "Redo" })
map("n", "<C-a>",      "ggVG",                        { desc = "Select all" })
map("n", "<C-d>",      "<cmd>t.<CR>",                 { desc = "Duplicate line (N++ Ctrl+D)" })
map("v", "<C-d>",      "y`>p",                        { desc = "Duplicate selection" })

-- ── Tabs (like N++ tab bar) ──────────────────────────────────
map("n", "<C-Tab>",    "<cmd>bnext<CR>",              { desc = "Next buffer/tab" })
map("n", "<C-S-Tab>",  "<cmd>bprev<CR>",              { desc = "Prev buffer/tab" })
map("n", "<A-1>",      "<cmd>BufferLineGoToBuffer 1<CR>", opts)
map("n", "<A-2>",      "<cmd>BufferLineGoToBuffer 2<CR>", opts)
map("n", "<A-3>",      "<cmd>BufferLineGoToBuffer 3<CR>", opts)
map("n", "<A-4>",      "<cmd>BufferLineGoToBuffer 4<CR>", opts)
map("n", "<A-5>",      "<cmd>BufferLineGoToBuffer 5<CR>", opts)

-- ── Search / Replace (like N++ Find dialog) ──────────────────
map("n", "<C-f>",      "<cmd>Telescope live_grep<CR>",  { desc = "Find in files" })
map("n", "<C-h>",      ":%s/",                          { desc = "Replace" })
map("n", "<F3>",       "n",                             { desc = "Find next" })
map("n", "<S-F3>",     "N",                             { desc = "Find prev" })
map("n", "<C-g>",      "<cmd>Telescope find_files<CR>", { desc = "Go to file" })

-- ── File Tree (N++ left panel) ────────────────────────────────
map("n", "<F1>",       "<cmd>NvimTreeToggle<CR>",      { desc = "Toggle file tree" })
map("n", "<leader>e",  "<cmd>NvimTreeFocus<CR>",       { desc = "Focus file tree" })

-- ── Comments (N++ block comment) ─────────────────────────────
map("n", "<C-q>",      "gcc",                          { desc = "Toggle comment", remap = true })
map("v", "<C-q>",      "gc",                           { desc = "Toggle comment", remap = true })

-- ── Terminal ──────────────────────────────────────────────────
map("n", "<C-`>",      "<cmd>ToggleTerm<CR>",          { desc = "Toggle terminal" })

-- ── LSP ───────────────────────────────────────────────────────
map("n", "gd",         vim.lsp.buf.definition,         { desc = "Go to definition" })
map("n", "gr",         "<cmd>Telescope lsp_references<CR>", { desc = "References" })
map("n", "K",          vim.lsp.buf.hover,              { desc = "Hover docs" })
map("n", "<leader>rn", vim.lsp.buf.rename,             { desc = "Rename symbol" })
map("n", "<leader>ca", vim.lsp.buf.code_action,        { desc = "Code action" })
map("n", "[d",         vim.diagnostic.goto_prev,       { desc = "Prev diagnostic" })
map("n", "]d",         vim.diagnostic.goto_next,       { desc = "Next diagnostic" })

-- ── Databricks ────────────────────────────────────────────────
map("n", "<leader>dc", "<cmd>DatabricksConnect<CR>",    { desc = "Databricks: Connect" })
map("n", "<leader>dr", "<cmd>DatabricksRunCell<CR>",    { desc = "Databricks: Run cell" })
map("n", "<leader>dR", "<cmd>DatabricksRunAll<CR>",     { desc = "Databricks: Run all" })
map("n", "<leader>dn", "<cmd>DatabricksNewNotebook<CR>",{ desc = "Databricks: New notebook" })
map("n", "<leader>dl", "<cmd>DatabricksListNotebooks<CR>",{ desc = "Databricks: List notebooks" })
map("n", "<leader>du", "<cmd>DatabricksUploadNotebook<CR>",{ desc = "Databricks: Upload notebook" })
map("n", "<leader>dw", "<cmd>DatabricksOpenWebUI<CR>",  { desc = "Databricks: Open Web UI" })
map("n", "<leader>ds", "<cmd>DatabricksStatus<CR>",     { desc = "Databricks: Cluster status" })

-- ── Window splits ─────────────────────────────────────────────
map("n", "<C-\\>",     "<cmd>vsplit<CR>",              { desc = "Vertical split" })
map("n", "<A-h>",      "<C-w>h", opts)
map("n", "<A-l>",      "<C-w>l", opts)
map("n", "<A-j>",      "<C-w>j", opts)
map("n", "<A-k>",      "<C-w>k", opts)

-- ── Fold (N++ collapsing blocks) ─────────────────────────────
map("n", "<C-kMinus>", "zc",                           { desc = "Fold block" })
map("n", "<C-kPlus>",  "zo",                           { desc = "Unfold block" })
map("n", "<A-0>",      "zM",                           { desc = "Fold all" })
map("n", "<A-S-0>",    "zR",                           { desc = "Unfold all" })
