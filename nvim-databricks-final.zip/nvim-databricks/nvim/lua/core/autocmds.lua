-- ============================================================
--  core/autocmds.lua — autocommands
-- ============================================================

local augroup = vim.api.nvim_create_augroup
local autocmd = vim.api.nvim_create_autocmd

-- ── Restore cursor position ───────────────────────────────────
autocmd("BufReadPost", {
  group = augroup("RestoreCursor", {}),
  callback = function()
    local mark = vim.api.nvim_buf_get_mark(0, '"')
    if mark[1] > 0 and mark[1] <= vim.api.nvim_buf_line_count(0) then
      vim.api.nvim_win_set_cursor(0, mark)
    end
  end,
})

-- ── Highlight on yank (N++ selection flash) ───────────────────
autocmd("TextYankPost", {
  group = augroup("HighlightYank", {}),
  callback = function()
    vim.highlight.on_yank({ higroup = "IncSearch", timeout = 150 })
  end,
})

-- ── Databricks cell markers ───────────────────────────────────
-- Highlight # COMMAND ----------- lines as cell separators
autocmd({ "BufEnter", "BufWinEnter" }, {
  group = augroup("DatabricksCells", {}),
  pattern = { "*.py", "*.sql", "*.scala", "*.r" },
  callback = function()
    -- Cell separator highlighting
    vim.fn.matchadd("DatabricksCellSep", "# COMMAND ----------\\(-*\\)")
    vim.fn.matchadd("DatabricksMagic",   "^# MAGIC .*")
    vim.fn.matchadd("DatabricksMarkdown","^# DBTITLE .*")
    -- Magic command % highlighting
    vim.fn.matchadd("DatabricksPct",     "^%%(python\\|sql\\|scala\\|r\\|md\\|sh\\|run\\|fs\\|jobs)")
  end,
})

-- ── Define highlight groups for Databricks ───────────────────
autocmd("ColorScheme", {
  group = augroup("DatabricksHL", {}),
  callback = function()
    vim.api.nvim_set_hl(0, "DatabricksCellSep", { fg = "#4ec9b0", bold = true, bg = "#1e3a2e" })
    vim.api.nvim_set_hl(0, "DatabricksMagic",   { fg = "#ce9178", italic = true })
    vim.api.nvim_set_hl(0, "DatabricksMarkdown",{ fg = "#d7ba7d", bold = true })
    vim.api.nvim_set_hl(0, "DatabricksPct",     { fg = "#569cd6", bold = true, bg = "#1e2a3a" })
  end,
})

-- ── Auto-format on save ───────────────────────────────────────
autocmd("BufWritePre", {
  group = augroup("AutoFormat", {}),
  pattern = { "*.py", "*.lua" },
  callback = function()
    if next(vim.lsp.buf_get_clients()) ~= nil then
      vim.lsp.buf.format({ async = false })
    end
  end,
})

-- ── Trim trailing whitespace ──────────────────────────────────
autocmd("BufWritePre", {
  group = augroup("TrimWhitespace", {}),
  callback = function()
    local pos = vim.api.nvim_win_get_cursor(0)
    vim.cmd([[%s/\s\+$//e]])
    vim.api.nvim_win_set_cursor(0, pos)
  end,
})
