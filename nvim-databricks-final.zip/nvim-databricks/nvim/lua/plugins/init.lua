return {
  {
    "ellisonleao/gruvbox.nvim",
    priority = 1000,
    config = function()
      require("gruvbox").setup({
        terminal_colors = true,
        undercurl = true,
        underline = true,
        bold = true,
        contrast = "hard",
        overrides = {
          Normal         = { bg = "#1e1e1e", fg = "#d4d4d4" },
          NormalNC       = { bg = "#1a1a1a" },
          LineNr         = { fg = "#608b4e", bg = "#1e1e1e" },
          CursorLine     = { bg = "#2a2d2e" },
          CursorLineNr   = { fg = "#4ec9b0", bold = true },
          Comment        = { fg = "#608b4e", italic = true },
          Keyword        = { fg = "#569cd6", bold = false },
          String         = { fg = "#ce9178" },
          Function       = { fg = "#dcdcaa" },
          Type           = { fg = "#4ec9b0" },
          Constant       = { fg = "#b5cea8" },
          Operator       = { fg = "#d4d4d4" },
          TabLine        = { bg = "#2d2d30", fg = "#9d9d9d" },
          TabLineSel     = { bg = "#1e1e1e", fg = "#ffffff", bold = true },
          TabLineFill    = { bg = "#2d2d30" },
          NvimTreeNormal = { bg = "#252526" },
          NvimTreeWinSeparator = { fg = "#3c3c3c" },
        },
      })
      vim.cmd("colorscheme gruvbox")
      vim.api.nvim_set_hl(0, "DatabricksCellSep", { fg = "#4ec9b0", bold = true, bg = "#1e3a2e" })
      vim.api.nvim_set_hl(0, "DatabricksMagic",   { fg = "#ce9178", italic = true })
      vim.api.nvim_set_hl(0, "DatabricksMarkdown",{ fg = "#d7ba7d", bold = true })
      vim.api.nvim_set_hl(0, "DatabricksPct",     { fg = "#569cd6", bold = true, bg = "#1e2a3a" })
    end,
  },
  {
    "akinsho/bufferline.nvim",
    version = "*",
    dependencies = "nvim-tree/nvim-web-devicons",
    config = function()
      require("bufferline").setup({
        options = {
          mode             = "buffers",
          numbers          = "ordinal",
          close_command    = "bdelete! %d",
          buffer_close_icon= "x",
          modified_icon    = "o",
          separator_style  = "thin",
          diagnostics      = "nvim_lsp",
          offsets = {
            { filetype = "NvimTree", text = "Explorer", text_align = "left", separator = true },
          },
        },
      })
    end,
  },
  {
    "nvim-lualine/lualine.nvim",
    dependencies = "nvim-tree/nvim-web-devicons",
    config = function()
      require("lualine").setup({
        options = {
          theme = "gruvbox",
          component_separators = { left = "", right = "" },
          section_separators   = { left = "", right = "" },
        },
        sections = {
          lualine_a = { "mode" },
          lualine_b = { "branch", "diff", "diagnostics" },
          lualine_c = { { "filename", path = 1 } },
          lualine_x = { "encoding", "fileformat", "filetype" },
          lualine_y = { "progress" },
          lualine_z = { "location" },
        },
      })
    end,
  },
  {
    "nvim-tree/nvim-tree.lua",
    dependencies = "nvim-tree/nvim-web-devicons",
    config = function()
      vim.g.loaded_netrw       = 1
      vim.g.loaded_netrwPlugin = 1
      require("nvim-tree").setup({
        view = { width = 32, side = "left" },
        renderer = { group_empty = true },
        filters  = { dotfiles = false },
      })
    end,
  },
  {
    "nvim-treesitter/nvim-treesitter",
    build = ":TSUpdate",
    config = function()
      require("nvim-treesitter.configs").setup({
        ensure_installed = { "python", "sql", "lua", "bash", "json", "yaml", "markdown" },
        highlight        = { enable = true },
        indent           = { enable = true },
      })
    end,
  },
  {
    "neovim/nvim-lspconfig",
    dependencies = {
      "williamboman/mason.nvim",
      "williamboman/mason-lspconfig.nvim",
      "hrsh7th/cmp-nvim-lsp",
    },
    config = function()
      require("mason").setup()
      require("mason-lspconfig").setup({
        ensure_installed = { "pyright" },
        automatic_installation = true,
      })
      local caps = require("cmp_nvim_lsp").default_capabilities()
      local ok, lsp = pcall(require, "lspconfig")
      if ok then
        lsp.pyright.setup({ capabilities = caps })
        lsp.lua_ls.setup({
          capabilities = caps,
          settings = { Lua = { diagnostics = { globals = { "vim" } } } },
        })
      end
    end,
  },
  {
    "hrsh7th/nvim-cmp",
    dependencies = {
      "hrsh7th/cmp-nvim-lsp",
      "hrsh7th/cmp-buffer",
      "hrsh7th/cmp-path",
      "L3MON4D3/LuaSnip",
      "saadparwaiz1/cmp_luasnip",
    },
    config = function()
      local cmp     = require("cmp")
      local luasnip = require("luasnip")
      cmp.setup({
        snippet = { expand = function(args) luasnip.lsp_expand(args.body) end },
        mapping = cmp.mapping.preset.insert({
          ["<C-Space>"] = cmp.mapping.complete(),
          ["<CR>"]      = cmp.mapping.confirm({ select = true }),
          ["<Tab>"]     = cmp.mapping(function(fallback)
            if cmp.visible() then cmp.select_next_item()
            else fallback() end
          end, { "i", "s" }),
        }),
        sources = cmp.config.sources({
          { name = "nvim_lsp" },
          { name = "luasnip" },
          { name = "buffer" },
          { name = "path" },
        }),
      })
    end,
  },
  {
    "nvim-telescope/telescope.nvim",
    dependencies = { "nvim-lua/plenary.nvim" },
    config = function()
      require("telescope").setup()
    end,
  },
  { "lewis6991/gitsigns.nvim", config = true },
  { "numToStr/Comment.nvim",   config = true },
  { "windwp/nvim-autopairs",   event = "InsertEnter", config = true },
  {
    "akinsho/toggleterm.nvim",
    config = function()
      require("toggleterm").setup({ size = 15, direction = "horizontal" })
    end,
  },
  {
    "folke/which-key.nvim",
    config = function()
      require("which-key").setup()
    end,
  },
}
