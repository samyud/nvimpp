-- ============================================================
--  plugins/databricks.lua — Databricks Notebook Integration
--  Supports: REST API v2.0, Workspace, Clusters, Jobs, Runs
-- ============================================================

local M = {}
local api = vim.api
local fn  = vim.fn

-- ── State ─────────────────────────────────────────────────────
M._state = {
  connected    = false,
  host         = nil,   -- e.g. https://adb-xxxx.azuredatabricks.net
  token        = nil,
  cluster_id   = nil,
  cluster_name = "N/A",
  state        = "UNKNOWN",
  context_id   = nil,   -- Execution context
}

local config_path = fn.stdpath("data") .. "/databricks_config.json"

-- ── Helpers ───────────────────────────────────────────────────

local function curl_request(method, path, body)
  local s = M._state
  if not s.host or not s.token then
    return nil, "Not connected. Run :DatabricksConnect first."
  end
  local url   = s.host .. "/api/2.0" .. path
  local cmd   = { "curl", "-s", "-X", method }
  local tmp_out = os.tmpname()
  local tmp_err = os.tmpname()

  table.insert(cmd, "-H")
  table.insert(cmd, "Authorization: Bearer " .. s.token)
  table.insert(cmd, "-H")
  table.insert(cmd, "Content-Type: application/json")

  if body then
    local tmp_body = os.tmpname()
    local f = io.open(tmp_body, "w")
    f:write(vim.json.encode(body))
    f:close()
    table.insert(cmd, "-d")
    table.insert(cmd, "@" .. tmp_body)
    table.insert(cmd, "--data-binary")
  end

  table.insert(cmd, url)
  table.insert(cmd, "-o")
  table.insert(cmd, tmp_out)

  fn.system(cmd)

  local f = io.open(tmp_out, "r")
  if not f then return nil, "Request failed" end
  local raw = f:read("*all")
  f:close()
  os.remove(tmp_out)

  local ok, decoded = pcall(vim.json.decode, raw)
  if not ok then return nil, "JSON parse error: " .. raw end
  if decoded.error_code then
    return nil, decoded.message or decoded.error_code
  end
  return decoded, nil
end

-- ── Config persistence ─────────────────────────────────────────

local function save_config()
  local f = io.open(config_path, "w")
  if f then
    f:write(vim.json.encode({
      host       = M._state.host,
      token      = M._state.token,
      cluster_id = M._state.cluster_id,
    }))
    f:close()
  end
end

local function load_config()
  local f = io.open(config_path, "r")
  if f then
    local raw = f:read("*all")
    f:close()
    local ok, cfg = pcall(vim.json.decode, raw)
    if ok and cfg then
      M._state.host       = cfg.host
      M._state.token      = cfg.token
      M._state.cluster_id = cfg.cluster_id
      return true
    end
  end
  return false
end

-- ── Public API ────────────────────────────────────────────────

function M.get_status()
  return {
    connected    = M._state.connected,
    cluster_name = M._state.cluster_name,
    state        = M._state.state,
    host         = M._state.host,
  }
end

-- Show connection dialog
function M.connect()
  -- Try loading saved config
  local had_config = load_config()
  local s = M._state

  local prompt_host = function(cb)
    vim.ui.input({
      prompt  = " Databricks Host (e.g. https://adb-xxx.azuredatabricks.net): ",
      default = s.host or "",
    }, function(input)
      if input and input ~= "" then
        s.host = input:gsub("/$", "")  -- strip trailing slash
        cb()
      else
        vim.notify("Connection cancelled.", vim.log.levels.WARN)
      end
    end)
  end

  local prompt_token = function(cb)
    vim.ui.input({
      prompt  = " Personal Access Token (dapiXXXX): ",
      default = "",
    }, function(input)
      if input and input ~= "" then
        s.token = input
        cb()
      else
        vim.notify("Connection cancelled.", vim.log.levels.WARN)
      end
    end)
  end

  local pick_cluster = function()
    vim.notify("Fetching clusters...", vim.log.levels.INFO)
    local data, err = curl_request("GET", "/clusters/list")
    if err then
      vim.notify("Error: " .. err, vim.log.levels.ERROR)
      return
    end

    local clusters = data.clusters or {}
    if #clusters == 0 then
      vim.notify("No clusters found.", vim.log.levels.WARN)
      return
    end

    local items = vim.tbl_map(function(c)
      return string.format("[%s] %s (%s)", c.cluster_id, c.cluster_name, c.state)
    end, clusters)

    vim.ui.select(items, {
      prompt = "Select Databricks Cluster:",
    }, function(choice, idx)
      if choice and idx then
        s.cluster_id   = clusters[idx].cluster_id
        s.cluster_name = clusters[idx].cluster_name
        s.state        = clusters[idx].state
        s.connected    = true
        save_config()
        vim.notify("✓ Connected to cluster: " .. s.cluster_name, vim.log.levels.INFO)
        -- Create execution context
        M._create_context()
      end
    end)
  end

  if had_config and s.host and s.token then
    vim.ui.input({
      prompt  = string.format(" Reconnect to %s? (y/n): ", s.host),
      default = "y",
    }, function(ans)
      if ans == "y" then
        pick_cluster()
      else
        prompt_host(function()
          prompt_token(pick_cluster)
        end)
      end
    end)
  else
    prompt_host(function()
      prompt_token(pick_cluster)
    end)
  end
end

-- Create an execution context on the cluster
function M._create_context()
  local s = M._state
  if not s.cluster_id then return end
  local data, err = curl_request("POST", "/contexts/create", {
    clusterId = s.cluster_id,
    language  = "python",
  })
  if err then
    vim.notify("Context error: " .. err, vim.log.levels.WARN)
    return
  end
  s.context_id = data.id
  vim.notify("Execution context ready.", vim.log.levels.INFO)
end

-- Detect cell language from magic command
local function detect_language(lines)
  for _, line in ipairs(lines) do
    local magic = line:match("^# MAGIC %%(%w+)") or line:match("^%%(%w+)")
    if magic then
      if magic == "sql"    then return "sql"    end
      if magic == "scala"  then return "scala"  end
      if magic == "r"      then return "r"      end
      if magic == "sh"     then return "sql"    end
      return "python"
    end
  end
  return "python"
end

-- Get current cell under cursor
local function get_current_cell()
  local bufnr = api.nvim_get_current_buf()
  local lines  = api.nvim_buf_get_lines(bufnr, 0, -1, false)
  local cursor = api.nvim_win_get_cursor(0)[1]
  local sep    = "# COMMAND ----------"

  local cell_start = 1
  local cell_end   = #lines

  -- Find cell boundaries
  for i = cursor, 1, -1 do
    if lines[i]:match("^# COMMAND %-%-%-") then
      cell_start = i + 1
      break
    end
  end
  for i = cursor + 1, #lines do
    if lines[i]:match("^# COMMAND %-%-%-") then
      cell_end = i - 1
      break
    end
  end

  local cell_lines = {}
  for i = cell_start, cell_end do
    local l = lines[i]
    -- Strip MAGIC prefix
    l = l:gsub("^# MAGIC ", "")
    table.insert(cell_lines, l)
  end

  return cell_lines, detect_language(cell_lines)
end

-- Run a single cell
function M.run_cell()
  local s = M._state
  if not s.connected then
    vim.notify("Not connected. Run :DatabricksConnect", vim.log.levels.ERROR)
    return
  end
  if not s.context_id then
    vim.notify("No execution context. Reconnect.", vim.log.levels.ERROR)
    return
  end

  local cell_lines, lang = get_current_cell()
  -- Remove magic line for execution
  local code = table.concat(cell_lines, "\n")

  vim.notify("▶ Running cell (" .. lang .. ")...", vim.log.levels.INFO)

  local data, err = curl_request("POST", "/contexts/run", {
    clusterId = s.cluster_id,
    contextId = s.context_id,
    language  = lang,
    command   = code,
  })
  if err then
    vim.notify("Run error: " .. err, vim.log.levels.ERROR)
    return
  end

  -- Poll for result
  local run_id = data.id
  M._poll_result(run_id)
end

-- Poll execution result
function M._poll_result(run_id)
  local s = M._state
  local max_polls = 120
  local poll_count = 0

  local function poll()
    poll_count = poll_count + 1
    if poll_count > max_polls then
      vim.notify("Execution timed out.", vim.log.levels.WARN)
      return
    end

    local data, err = curl_request("GET", string.format(
      "/contexts/status?clusterId=%s&contextId=%s&commandId=%s",
      s.cluster_id, s.context_id, run_id
    ))

    if err then
      vim.notify("Poll error: " .. err, vim.log.levels.ERROR)
      return
    end

    local status = data.status
    if status == "Running" or status == "Queued" then
      vim.defer_fn(poll, 1000)
      return
    end

    -- Finished
    local results = data.results
    if not results then
      vim.notify("No results returned.", vim.log.levels.WARN)
      return
    end

    if results.resultType == "error" then
      vim.notify("✗ Error:\n" .. (results.cause or results.summary or "Unknown error"), vim.log.levels.ERROR)
      M._show_output_window("ERROR", results.cause or results.summary or "")
      return
    end

    local output = results.data or ""
    if results.resultType == "table" then
      output = M._format_table(results)
    elseif results.resultType == "images" then
      output = "[Image output — open Web UI to view]"
    end

    vim.notify("✓ Cell executed successfully.", vim.log.levels.INFO)
    M._show_output_window("OUTPUT", output)
  end

  vim.defer_fn(poll, 500)
end

-- Format tabular output
function M._format_table(results)
  if not results.schema or not results.data then return tostring(results.data) end
  local headers = vim.tbl_map(function(c) return c.name end, results.schema)
  local rows    = results.data
  local lines   = {}

  -- Widths
  local widths = vim.tbl_map(function(h) return #h end, headers)
  for _, row in ipairs(rows) do
    for i, cell in ipairs(row) do
      widths[i] = math.max(widths[i] or 0, #tostring(cell))
    end
  end

  -- Header
  local sep = "+" .. table.concat(vim.tbl_map(function(w) return string.rep("-", w + 2) end, widths), "+") .. "+"
  table.insert(lines, sep)
  local header_row = "| "
  for i, h in ipairs(headers) do
    header_row = header_row .. h .. string.rep(" ", widths[i] - #h) .. " | "
  end
  table.insert(lines, header_row)
  table.insert(lines, sep)

  -- Data rows
  for _, row in ipairs(rows) do
    local data_row = "| "
    for i, cell in ipairs(row) do
      local s = tostring(cell)
      data_row = data_row .. s .. string.rep(" ", widths[i] - #s) .. " | "
    end
    table.insert(lines, data_row)
  end
  table.insert(lines, sep)

  return table.concat(lines, "\n")
end

-- Show output in a floating window
function M._show_output_window(title, content)
  local lines = vim.split(content, "\n")
  local width  = math.min(120, vim.o.columns - 4)
  local height = math.min(#lines + 2, math.floor(vim.o.lines * 0.4))

  local bufnr = api.nvim_create_buf(false, true)
  api.nvim_buf_set_lines(bufnr, 0, -1, false, lines)
  api.nvim_buf_set_option(bufnr, "modifiable", false)
  api.nvim_buf_set_option(bufnr, "filetype", "databricks_output")

  local win = api.nvim_open_win(bufnr, true, {
    relative = "editor",
    width    = width,
    height   = height,
    row      = vim.o.lines - height - 4,
    col      = math.floor((vim.o.columns - width) / 2),
    style    = "minimal",
    border   = "rounded",
    title    = " " .. title .. " ",
    title_pos = "center",
    footer    = " [q] close ",
    footer_pos = "right",
  })

  -- Styling
  api.nvim_win_set_option(win, "winhl",
    "Normal:NormalFloat,FloatBorder:FloatBorder,FloatTitle:FloatTitle")

  -- Close with q
  vim.keymap.set("n", "q", "<cmd>close<CR>", { buffer = bufnr, silent = true })
  vim.keymap.set("n", "<Esc>", "<cmd>close<CR>", { buffer = bufnr, silent = true })
end

-- Run all cells
function M.run_all()
  local s = M._state
  if not s.connected then
    vim.notify("Not connected.", vim.log.levels.ERROR)
    return
  end
  local bufnr = api.nvim_get_current_buf()
  local lines  = api.nvim_buf_get_lines(bufnr, 0, -1, false)

  -- Split into cells
  local cells   = {}
  local current = {}
  for _, line in ipairs(lines) do
    if line:match("^# COMMAND %-%-%-") then
      if #current > 0 then
        table.insert(cells, current)
        current = {}
      end
    else
      table.insert(current, line)
    end
  end
  if #current > 0 then table.insert(cells, current) end

  vim.notify(string.format("Running %d cells...", #cells), vim.log.levels.INFO)
  -- Sequential execution via recursion
  local function run_next(idx)
    if idx > #cells then
      vim.notify("✓ All cells executed.", vim.log.levels.INFO)
      return
    end
    local cell_lines = cells[idx]
    local lang       = detect_language(cell_lines)
    local code       = table.concat(vim.tbl_map(function(l)
      return l:gsub("^# MAGIC ", "")
    end, cell_lines), "\n")

    curl_request("POST", "/contexts/run", {
      clusterId = s.cluster_id,
      contextId = s.context_id,
      language  = lang,
      command   = code,
    })
    -- Small delay between cells
    vim.defer_fn(function() run_next(idx + 1) end, 200)
  end
  run_next(1)
end

-- List workspace notebooks
function M.list_notebooks()
  vim.ui.input({
    prompt  = " Workspace path (default: /): ",
    default = "/",
  }, function(path)
    if not path then return end
    local data, err = curl_request("GET", "/workspace/list?path=" .. vim.uri_encode(path))
    if err then
      vim.notify("Error: " .. err, vim.log.levels.ERROR)
      return
    end

    local objects = data.objects or {}
    if #objects == 0 then
      vim.notify("No objects found at " .. path, vim.log.levels.WARN)
      return
    end

    local items = vim.tbl_map(function(o)
      local icon = o.object_type == "NOTEBOOK" and "📓" or
                   o.object_type == "DIRECTORY" and "📁" or "📄"
      return string.format("%s  %s  [%s]", icon, o.path, o.object_type)
    end, objects)

    vim.ui.select(items, { prompt = "Workspace — " .. path .. ":" }, function(_, idx)
      if not idx then return end
      local obj = objects[idx]
      if obj.object_type == "NOTEBOOK" then
        M._export_notebook(obj.path)
      elseif obj.object_type == "DIRECTORY" then
        M.list_notebooks_at(obj.path)
      end
    end)
  end)
end

-- Export and open a notebook
function M._export_notebook(path)
  vim.notify("Downloading notebook: " .. path, vim.log.levels.INFO)
  local data, err = curl_request("GET",
    "/workspace/export?path=" .. vim.uri_encode(path) .. "&format=SOURCE&direct_download=true")
  if err then
    vim.notify("Export error: " .. err, vim.log.levels.ERROR)
    return
  end

  local content = data.content or ""
  -- Base64 decode
  local decoded = vim.base64.decode(content)

  -- Write to temp file and open
  local fname = fn.stdpath("data") .. "/databricks_notebooks" ..
                path:gsub("/", "_"):gsub("%.%w+$", "") .. ".py"
  fn.mkdir(fn.fnamemodify(fname, ":h"), "p")

  local f = io.open(fname, "w")
  if f then
    f:write(decoded)
    f:close()
    vim.cmd("edit " .. fn.fnameescape(fname))
    vim.notify("✓ Notebook opened: " .. path, vim.log.levels.INFO)
  end
end

-- Upload current buffer as notebook
function M.upload_notebook()
  local bufnr = api.nvim_get_current_buf()
  local fname  = api.nvim_buf_get_name(bufnr)
  local lines  = api.nvim_buf_get_lines(bufnr, 0, -1, false)
  local content = table.concat(lines, "\n")
  local b64     = vim.base64.encode(content)

  vim.ui.input({
    prompt  = " Upload to workspace path: ",
    default = "/Users/me/" .. fn.fnamemodify(fname, ":t:r"),
  }, function(path)
    if not path then return end
    local _, err = curl_request("POST", "/workspace/import", {
      path      = path,
      format    = "SOURCE",
      language  = "PYTHON",
      content   = b64,
      overwrite = true,
    })
    if err then
      vim.notify("Upload error: " .. err, vim.log.levels.ERROR)
      return
    end
    vim.notify("✓ Uploaded to " .. path, vim.log.levels.INFO)
  end)
end

-- New notebook buffer with template
function M.new_notebook()
  vim.cmd("enew")
  api.nvim_buf_set_option(0, "filetype", "python")

  local template = {
    "# Databricks notebook source",
    "# MAGIC %python",
    "",
    "# COMMAND ----------",
    "",
    "# MAGIC %md",
    "# MAGIC ## My Notebook",
    "# MAGIC This is a Databricks notebook.",
    "",
    "# COMMAND ----------",
    "",
    "# Hello World",
    'print("Hello from Databricks!")',
    "",
    "# COMMAND ----------",
    "",
    "# MAGIC %sql",
    "# MAGIC SELECT current_timestamp()",
    "",
    "# COMMAND ----------",
  }
  api.nvim_buf_set_lines(0, 0, -1, false, template)
  vim.notify("✓ New Databricks notebook created. Use :DatabricksConnect to connect.", vim.log.levels.INFO)
end

-- Show cluster status
function M.status()
  local s = M._state
  if not s.connected then
    vim.notify("Not connected. Run :DatabricksConnect", vim.log.levels.WARN)
    return
  end

  local data, err = curl_request("GET", "/clusters/get?cluster_id=" .. s.cluster_id)
  if err then
    vim.notify("Status error: " .. err, vim.log.levels.ERROR)
    return
  end

  s.state        = data.state
  s.cluster_name = data.cluster_name

  local info = {
    "Cluster:    " .. data.cluster_name,
    "ID:         " .. data.cluster_id,
    "State:      " .. data.state,
    "Driver:     " .. (data.driver_node_type_id or "N/A"),
    "Workers:    " .. tostring(data.num_workers or "Auto"),
    "Spark Ver:  " .. (data.spark_version or "N/A"),
    "Creator:    " .. (data.creator_user_name or "N/A"),
  }
  M._show_output_window("Cluster Status", table.concat(info, "\n"))
end

-- Open the Web UI
function M.open_web_ui()
  local s = M._state
  -- Launch the bundled web UI server
  local web_ui_path = fn.stdpath("config") .. "/databricks-web/index.html"
  if fn.filereadable(web_ui_path) == 1 then
    fn.system({"xdg-open", "file://" .. web_ui_path, "&"})
    vim.notify("Opening Databricks Web UI...", vim.log.levels.INFO)
  else
    vim.notify("Web UI not found at: " .. web_ui_path, vim.log.levels.WARN)
  end
end

-- ── Setup & Commands ──────────────────────────────────────────

function M.setup()
  -- Try loading saved config on startup
  load_config()

  -- Register commands
  local cmds = {
    DatabricksConnect        = M.connect,
    DatabricksRunCell        = M.run_cell,
    DatabricksRunAll         = M.run_all,
    DatabricksNewNotebook    = M.new_notebook,
    DatabricksListNotebooks  = M.list_notebooks,
    DatabricksUploadNotebook = M.upload_notebook,
    DatabricksStatus         = M.status,
    DatabricksOpenWebUI      = M.open_web_ui,
  }

  for name, fn_ref in pairs(cmds) do
    vim.api.nvim_create_user_command(name, fn_ref, {})
  end

  -- Cell navigation
  vim.api.nvim_create_user_command("DatabricksNextCell", function()
    fn.search("^# COMMAND ----------", "W")
  end, {})
  vim.api.nvim_create_user_command("DatabricksPrevCell", function()
    fn.search("^# COMMAND ----------", "bW")
  end, {})

  vim.keymap.set("n", "]c", "<cmd>DatabricksNextCell<CR>", { desc = "Next Databricks cell" })
  vim.keymap.set("n", "[c", "<cmd>DatabricksPrevCell<CR>", { desc = "Prev Databricks cell" })
end

return M
